<?php
declare(strict_types=1);

/** Начальные виды работ (ТЗ 3.2, 11.3) и счётчик номеров дверей. Идемпотентно. */
return static function (PDO $pdo): void {
    $stmt = $pdo->prepare(
        'INSERT IGNORE INTO work_types (name, description, unit, door_required, allow_multiple_per_door, is_active)
         VALUES (:name, :description, :unit, 1, 0, 1)'
    );
    foreach ([
        ['Ремонт двери',  'Ремонт межкомнатной двери',  'шт'],
        ['Упаковка двери', 'Упаковка межкомнатной двери', 'шт'],
    ] as [$name, $description, $unit]) {
        $stmt->execute(['name' => $name, 'description' => $description, 'unit' => $unit]);
    }

    $pdo->exec("INSERT IGNORE INTO door_sequences (name, last_value) VALUES ('door', 0)");
};
