<?php
declare(strict_types=1);

namespace Tests\Unit;

use App\Helpers\Money;
use PHPUnit\Framework\TestCase;

final class MoneyTest extends TestCase
{
    public function testPriceAcceptsNumbersAndStrings(): void
    {
        $this->assertSame('500.00', Money::price('500'));
        $this->assertSame('12.50', Money::price('12.5'));
        $this->assertSame('12.50', Money::price(12.5));
        $this->assertSame('0.00', Money::price(0));
        $this->assertSame('9999999.99', Money::price('9999999.99'));
    }

    public function testPriceRejectsBadValues(): void
    {
        foreach (['1.234', '-1', 'abc', '', '10000000', true, null, [], '1e3', '1,5'] as $bad) {
            $this->assertNull(Money::price($bad), var_export($bad, true));
        }
    }

    public function testQuantity(): void
    {
        $this->assertSame('1.000', Money::quantity('1'));
        $this->assertSame('0.500', Money::quantity(0.5));
        $this->assertNull(Money::quantity('1.2345'));
        $this->assertNull(Money::quantity('100000'));
        $this->assertTrue(Money::isPositive('0.001'));
        $this->assertFalse(Money::isPositive('0.000'));
    }

    public function testMultiplyRoundsHalfUpWithoutFloatErrors(): void
    {
        $this->assertSame('500.00', Money::multiply('1.000', '500.00'));
        $this->assertSame('0.13', Money::multiply('0.250', '0.50'));      // 0.125 -> 0.13
        $this->assertSame('0.12', Money::multiply('0.249', '0.50'));      // 0.1245 -> 0.12
        $this->assertSame('499.98', Money::multiply('2.500', '199.99'));  // 499.975 -> 499.98
        $this->assertSame('99.99', Money::multiply('3.000', '33.33'));
        $this->assertSame('0.30', Money::multiply('3.000', '0.10'));      // классическая ловушка 0.1*3 во float
    }

    public function testMaximumFitsIntoDecimal14_2(): void
    {
        $max = Money::multiply('99999.999', '9999999.99');
        $this->assertLessThanOrEqual(0, bccomp($max, '999999999999.99', 2));
    }
}
