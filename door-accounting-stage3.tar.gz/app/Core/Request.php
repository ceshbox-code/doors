<?php
declare(strict_types=1);

namespace App\Core;

final class Request
{
    public string $method;
    public string $path;
    public array $query;
    public array $headers;
    public array $params;
    public string $ip;
    /** Текущий пользователь; заполняется Guard после проверки сессии. */
    public ?array $user = null;
    private ?string $rawBody;

    public function __construct(
        string $method,
        string $path,
        array $query = [],
        array $headers = [],
        array $params = [],
        ?string $rawBody = null,
        string $ip = '0.0.0.0'
    ) {
        $this->method  = $method;
        $this->path    = $path;
        $this->query   = $query;
        $this->headers = $headers;
        $this->params  = $params;
        $this->rawBody = $rawBody;
        $this->ip      = $ip;
    }

    public static function fromGlobals(): self
    {
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $headers = [];
        foreach ($_SERVER as $k => $v) {
            if (str_starts_with($k, 'HTTP_')) {
                $headers[strtolower(str_replace('_', '-', substr($k, 5)))] = (string) $v;
            }
        }
        return new self(
            strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'),
            '/' . trim($uri, '/'),
            $_GET,
            $headers,
            [],
            null,
            (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0')
        );
    }

    public function withParams(array $params): self
    {
        $c = clone $this;
        $c->params = $params;
        return $c;
    }

    public function withUser(array $user): self
    {
        $c = clone $this;
        $c->user = $user;
        return $c;
    }

    public function header(string $name): ?string
    {
        return $this->headers[strtolower($name)] ?? null;
    }

    /** Тело запроса как JSON-объект. Пустое тело — пустой массив; некорректное — ошибка 400. */
    public function json(): array
    {
        $this->rawBody ??= (string) file_get_contents('php://input');
        if (trim($this->rawBody) === '') {
            return [];
        }
        $data = json_decode($this->rawBody, true);
        if (!is_array($data)) {
            throw new ApiException('INVALID_JSON', 'Тело запроса должно быть корректным JSON-объектом', 400);
        }
        return $data;
    }
}
