<?php
declare(strict_types=1);

namespace App\Core;

final class Response
{
    public int $status;
    public array $body;
    /** @var array<string,string> */
    public array $headers = [];

    public function __construct(int $status, array $body)
    {
        $this->status = $status;
        $this->body   = $body;
    }

    public static function ok($data = null, int $status = 200): self
    {
        return new self($status, ['success' => true, 'data' => $data]);
    }

    /** Единый формат ошибок из ТЗ, п. 12.11 (details — необязательное расширение для ошибок полей). */
    public static function error(string $code, string $message, int $status = 400, ?array $details = null): self
    {
        $error = ['code' => $code, 'message' => $message];
        if ($details !== null) {
            $error['details'] = $details;
        }
        return new self($status, ['success' => false, 'error' => $error]);
    }

    public function withHeader(string $name, string $value): self
    {
        $this->headers[$name] = $value;
        return $this;
    }

    public function send(): void
    {
        foreach ($this->headers as $n => $v) {
            header($n . ': ' . $v);
        }
        http_response_code($this->status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');
        echo json_encode($this->body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }
}
